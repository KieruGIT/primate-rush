import numpy as np, math, random
from PIL import Image

random.seed(11)
W, H = 480, 270
img = np.zeros((H, W, 3), np.float32)
L = np.zeros((H, W, 3), np.float32)
BAY = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0


def C(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], np.float32)


def px(x, y, c):
    x, y = int(x), int(y)
    if 0 <= x < W and 0 <= y < H:
        img[y, x] = c


def rect(x0, y0, x1, y1, c):
    x0, y0, x1, y1 = max(0, int(x0)), max(0, int(y0)), min(W, int(x1)), min(H, int(y1))
    if x1 > x0 and y1 > y0:
        img[y0:y1, x0:x1] = c


def disc(cx, cy, r, c, dither=None):
    for y in range(int(cy - r - 1), int(cy + r + 2)):
        for x in range(int(cx - r - 1), int(cx + r + 2)):
            if (x + .5 - cx) ** 2 + (y + .5 - cy) ** 2 <= r * r:
                if dither is None or BAY[y % 4, x % 4] < dither:
                    px(x, y, c)


def poly(pts, c):
    ys = [p[1] for p in pts]
    for y in range(int(min(ys)), int(max(ys)) + 1):
        xs = []
        n = len(pts)
        for i in range(n):
            (x0, y0), (x1, y1) = pts[i], pts[(i + 1) % n]
            if (y0 <= y + .5 < y1) or (y1 <= y + .5 < y0):
                xs.append(x0 + (y + .5 - y0) * (x1 - x0) / (y1 - y0))
        xs.sort()
        for a, b in zip(xs[::2], xs[1::2]):
            rect(round(a), y, round(b), y + 1, c)


def light(cx, cy, r, col, k=1.0):
    y0, y1 = max(0, int(cy - r)), min(H, int(cy + r))
    x0, x1 = max(0, int(cx - r)), min(W, int(cx + r))
    yy, xx = np.mgrid[y0:y1, x0:x1]
    d = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / r
    f = np.clip(1 - d, 0, 1) ** 1.6 * k
    L[y0:y1, x0:x1] += f[..., None] * np.array(col, np.float32)


# ---------- sky ----------
sky = [C(c) for c in ['#060a1a', '#0a1026', '#0e1634', '#131e44', '#1a2852', '#223463', '#2b3f70']]
for y in range(H):
    t = min(1, y / 200) * (len(sky) - 1)
    i = int(t)
    f = t - i
    for x in range(W):
        img[y, x] = sky[min(i + (1 if f > BAY[y % 4, x % 4] else 0), len(sky) - 1)]
for _ in range(110):
    x, y = random.randrange(W), random.randrange(150)
    b = random.choice([0.45, 0.6, 0.8, 1.0])
    px(x, y, C('#f4e9cf') * b)
for (x, y) in [(40, 20), (128, 44), (270, 14), (452, 96), (186, 70)]:
    for d in (-1, 1):
        px(x + d, y, C('#9fb4e8'))
        px(x, y + d, C('#9fb4e8'))
    px(x, y, C('#ffffff'))
# moon
disc(402, 34, 13, C('#f2e8c8'))
disc(409, 29, 12, sky[1])
disc(402, 34, 24, C('#1c2a5a'), dither=0.18)
light(402, 34, 60, (0.35, 0.42, 0.7), 0.35)

# ---------- far mountain + temple ----------
mt = [(230, 205), (262, 150), (276, 156), (296, 112), (312, 80), (322, 62), (330, 50), (338, 62), (348, 80), (366, 112), (384, 150), (398, 146), (440, 205)]
poly(mt, C('#121a38'))
poly([(330, 50), (338, 62), (348, 80), (366, 112), (384, 150), (398, 146), (440, 205), (330, 205)], C('#0f1630'))
for i, (w, h) in enumerate([(26, 4), (20, 4), (14, 4), (8, 3)]):
    rect(330 - w // 2, 52 - i * 4, 330 + w // 2, 52 - i * 4 + h, C('#1e2a55') if i % 2 == 0 else C('#243263'))
rect(328, 46, 332, 50, C('#ffd84a'))
for ang in (-0.5, -0.2, 0.15, 0.45):
    for r in range(4, 70):
        x = 330 + math.sin(ang) * r
        y = 44 - math.cos(ang) * r
        for w in range(-(r // 14), r // 14 + 1):
            xx, yy = int(x + w), int(y)
            if 0 <= xx < W and 0 <= yy < H and BAY[yy % 4, xx % 4] < 0.35:
                img[yy, xx] = img[yy, xx] * 0.6 + C('#ffd84a') * 0.4
light(330, 46, 55, (1.0, 0.8, 0.3), 0.9)

# ---------- jungle ridges ----------
def ridge(base, amp, col, seed, bump):
    rnd = random.Random(seed)
    ph = [rnd.random() * 6 for _ in range(3)]
    for x in range(W):
        h = base + amp * (math.sin(x / 23 + ph[0]) * .5 + math.sin(x / 9 + ph[1]) * .3 + math.sin(x / 4.3 + ph[2]) * .2)
        rect(x, h, x + 1, H, col)
    for _ in range(int(W / 7)):
        x = rnd.randrange(W)
        disc(x, base - amp * 0.4 + rnd.random() * 6, bump * (0.6 + rnd.random() * 0.6), col)


ridge(186, 10, C('#0b1d24'), 1, 9)
for (x0, h) in [(84, 34), (104, 24), (262, 30)]:
    rect(x0, 206 - h, x0 + 8, 206, C('#18203c'))
    rect(x0 - 1, 206 - h, x0 + 9, 206 - h + 3, C('#1d2748'))
rect(84, 172, 112, 176, C('#18203c'))
ridge(204, 8, C('#0d2522'), 2, 8)

# ---------- waterfall cliff ----------
rock = [C('#2a2f48'), C('#333a58'), C('#232840')]
for x in range(306, 364):
    top = 92 + int(3 * math.sin(x / 5))
    for y in range(top, 236):
        img[y, x] = rock[(x // 6 + y // 5) % 3] if (y % 5 and (x + (y // 5) * 3) % 9) else C('#191c2e')
rect(306, 88, 364, 93, C('#3f7a34'))
rect(306, 88, 364, 89, C('#7ec85a'))
wcol = [C('#b7e6f7'), C('#7fc0e6'), C('#5596cf'), C('#3f78b4')]
for x in range(320, 350):
    for y in range(93, 236):
        k = (y + (x * 7) % 11 + (x // 3) * 5) % 12
        img[y, x] = wcol[0 if k < 2 else 1 if k < 5 else 2 if k < 9 else 3]
    img[93:236, 320] = C('#dff4ff')
    img[93:236, 349] = C('#2f5f96')
for y in range(214, 240):
    for x in range(308, 364):
        if BAY[y % 4, x % 4] < 0.3 * (1 - abs(x - 335) / 30) * min(1, (y - 212) / 10):
            img[y, x] = C('#e6f6ff')
for i in range(12):
    x = 312 + random.randrange(8)
    rect(x, 93, x + 1, 93 + random.randrange(4, 18), C('#3f7a34'))
    x = 352 + random.randrange(10)
    rect(x, 93, x + 1, 93 + random.randrange(4, 18), C('#3f7a34'))

# ---------- trees ----------
def trunk(x0, x1, y0, y1, dark=False):
    base = C('#3a2416') if dark else C('#4d321e')
    for x in range(x0, x1):
        for y in range(y0, y1):
            c = base.copy()
            if (x - x0) in (1, 2):
                c = base * 1.25
            if (x - x0) >= x1 - x0 - 3:
                c = base * 0.7
            if (x * 3 + y // 7) % 7 == 0:
                c = base * 0.72
            if (y + x * 5) % 23 == 0:
                c = base * 0.6
            img[y, x] = c
    rect(x0 - 1, y0, x0, y1, C('#140a06'))
    rect(x1, y0, x1 + 1, y1, C('#140a06'))


def leafclump(cx, cy, r, shade=1.0):
    disc(cx + 1, cy + 1, r + 1, C('#081610') * shade)
    disc(cx, cy, r, C('#1d4a2c') * shade)
    disc(cx - r * .3, cy - r * .3, r * .6, C('#2a6a38') * shade)
    disc(cx - r * .45, cy - r * .45, r * .25, C('#4f9a3a') * shade)


trunk(150, 158, 120, 236, dark=True)
trunk(10, 32, 40, 236)
trunk(446, 462, 60, 236)
for x in range(-10, W + 20, 13):
    leafclump(x + random.randrange(-4, 4), random.randrange(-6, 10), random.randrange(10, 16), 0.85)
for (cx, cy, r) in [(20, 36, 16), (40, 22, 14), (-2, 20, 12), (454, 52, 15), (472, 34, 14), (436, 30, 12), (154, 112, 11), (164, 100, 9)]:
    leafclump(cx, cy, r)


def vine(pts, leaf=True):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n):
            x = x0 + (x1 - x0) * i / n
            y = y0 + (y1 - y0) * i / n
            px(x, y, C('#3f7a34'))
            px(x + 1, y, C('#28521f'))
            if leaf and int(y) % 7 == 0:
                s = -2 if int(y) % 14 else 2
                px(x + s, y, C('#5aa33f'))
                px(x + s, y - 1, C('#7ec85a'))
                px(x + s + (1 if s > 0 else -1), y, C('#4f9a3a'))


vine([(140, 0), (141, 40), (139, 80), (141, 118)])
vine([(112, 0), (113, 30), (111, 58)])
vine([(470, 0), (469, 40), (471, 90)])
vine([(284, 0), (292, 30), (300, 58), (306, 76)])

# ---------- platforms ----------
def stone_platform(x0, x1, y, th):
    cols = [C('#5a607a'), C('#4e5470'), C('#666c88'), C('#555b76')]
    for yy in range(y, y + th):
        row = (yy - y) // 4
        for x in range(x0, x1):
            off = 4 if row % 2 else 0
            if (yy - y) % 4 == 3 or (x - x0 + off) % 9 == 0:
                img[yy, x] = C('#262a3c')
            else:
                c = cols[((x - x0 + off) // 9 + row) % 4]
                if (yy - y) % 4 == 0:
                    c = c * 1.18
                img[yy, x] = c
    rect(x0 - 1, y - 1, x1 + 1, y, C('#140a06'))
    rect(x0 - 1, y + th, x1 + 1, y + th + 1, C('#140a06'))
    rect(x0 - 1, y, x0, y + th, C('#140a06'))
    rect(x1, y, x1 + 1, y + th, C('#140a06'))
    rect(x0, y - 3, x1, y, C('#4f9a3a'))
    rect(x0, y - 3, x1, y - 2, C('#7ec85a'))
    for x in range(x0, x1, 3):
        if random.random() < .6:
            px(x, y - 4, C('#7ec85a'))
            if random.random() < .4:
                px(x, y - 5, C('#5aa33f'))
    for x in range(x0 + 2, x1 - 2, 4):
        if random.random() < .45:
            for d in range(random.randrange(2, 7)):
                px(x, y + th + d, C('#3f7a34') if d % 2 else C('#2f6b24'))


def wood_platform(x0, x1, y):
    for x in range(x0, x1):
        for yy in range(y, y + 7):
            c = C('#7a5230')
            if (x - x0) % 11 == 0:
                c = C('#3a2416')
            elif yy == y:
                c = C('#a0703f')
            elif yy >= y + 5:
                c = C('#5c3a1c')
            img[yy, x] = c
    for x in range(x0 + 5, x1, 11):
        px(x, y + 2, C('#c9a36a'))
    rect(x0 - 1, y - 1, x1 + 1, y, C('#140a06'))
    rect(x0 - 1, y + 7, x1 + 1, y + 8, C('#140a06'))
    for rx in (x0 + 4, x1 - 5):
        for yy in range(0, y):
            if yy % 3:
                px(rx, yy, C('#b08a5a'))


wood_platform(36, 122, 186)
stone_platform(150, 264, 150, 14)
stone_platform(366, 460, 128, 12)
stone_platform(200, 254, 90, 10)
for sx in (204, 248):
    rect(sx, 72, sx + 4, 88, C('#666c88'))
    rect(sx, 72, sx + 1, 88, C('#8a90ac'))
    rect(sx - 1, 70, sx + 5, 72, C('#7a809c'))

# ---------- ground ----------
for x in range(W):
    for y in range(236, H):
        c = C('#3a2616') if y < 250 else C('#2c1c10')
        if (x * 7 + y * 13) % 29 == 0:
            c = C('#5c3f28')
        if (x * 3 + y * 5) % 41 == 0:
            c = C('#1e130a')
        img[y, x] = c
rect(0, 236, W, 240, C('#4f9a3a'))
rect(0, 236, W, 237, C('#8fd14f'))
rect(0, 240, W, 241, C('#2f6b24'))
for x in range(0, W, 2):
    h = random.choice([0, 1, 1, 2, 3])
    for d in range(h):
        px(x, 235 - d, C('#5aa33f') if d else C('#7ec85a'))
for x in range(0, W, 23):
    rx = x + random.randrange(10)
    for d in range(8):
        px(rx + d // 3, 244 + d, C('#5c3a1c'))

for x in range(-6, W + 10, 17):
    if 300 < x < 370:
        continue
    leafclump(x + random.randrange(-3, 4), 236 - random.randrange(0, 4), random.randrange(6, 10), 0.72)
rect(0, 238, W, 240, C('#4f9a3a'))
rect(0, 240, W, 241, C('#2f6b24'))

# ---------- torches ----------
def torch(x, y):
    rect(x, y - 12, x + 2, y, C('#5c3a1c'))
    rect(x - 2, y - 14, x + 4, y - 12, C('#3a2416'))
    for (dx, dy, c) in [(-1, -15, '#ff6a1c'), (0, -15, '#ff9a3c'), (1, -15, '#ff9a3c'), (2, -15, '#ff6a1c'),
                        (0, -16, '#ffd84a'), (1, -16, '#ff9a3c'), (-1, -16, '#ff6a1c'), (0, -17, '#ff9a3c'), (1, -17, '#ffd84a'), (1, -18, '#ff6a1c')]:
        px(x + dx, y + dy, C(c))
    light(x + 1, y - 16, 58, (1.0, 0.55, 0.22), 1.0)


torch(160, 147)
torch(126, 236)
torch(292, 236)
torch(452, 125)

# ---------- sprites ----------
BAN = ['.......OO.', '......OYO.', '.....OHYO.', '....OYYDO.', '...OYYYO..', 'OOOYYYDO..', 'OYYYDDO...', '.OOOOO....']


def banana(x, y, gold=False, s=1):
    pal = {'O': C('#5a3a00'), 'Y': C('#ffe45c'), 'D': C('#f0a500'), 'H': C('#fffbe0')} if gold else \
        {'O': C('#140a06'), 'Y': C('#f7c948'), 'D': C('#d49a1f'), 'H': C('#fff3b0')}
    for j, row in enumerate(BAN):
        for i, ch in enumerate(row):
            if ch in pal:
                rect(x + i * s, y + j * s, x + i * s + s, y + j * s + s, pal[ch])




def blit(spr, cx, bottom, flip=False, top=None):
    if flip:
        spr = spr[:, ::-1]
    h, w = spr.shape[:2]
    x0 = int(cx - w / 2)
    y0 = int(top) if top is not None else int(bottom - h)
    for y in range(h):
        for x in range(w):
            if spr[y, x, 3] > 0:
                px(x0 + x, y0 + y, spr[y, x, :3])
    return x0, y0, w, h


placed = {}
# bananas
for (x, y) in [(46, 179), (60, 179), (98, 179), (380, 121), (394, 121), (408, 121), (140, 229), (156, 229), (362, 229), (378, 229), (420, 229), (176, 143)]:
    banana(x, y)
banana(210, 60, gold=True, s=2)
for (x, y) in [(206, 58), (234, 62), (226, 54)]:
    px(x, y, C('#ffffff')); px(x - 1, y, C('#fff1a8')); px(x + 1, y, C('#fff1a8')); px(x, y - 1, C('#fff1a8')); px(x, y + 1, C('#fff1a8'))
light(220, 68, 70, (1.0, 0.85, 0.35), 1.1)
for yy in range(0, 60):
    for xx in range(216, 226):
        if BAY[yy % 4, xx % 4] < 0.12 + 0.1 * (yy / 60):
            img[yy, xx] = img[yy, xx] * 0.5 + C('#ffd84a') * 0.5

# characters
import anim2 as A
from PIL import Image as _I


def chibi(k, fr, hat='none', fur=None, face=None, flip=False, sc=2):
    rows = A.dress(k, fr, hat)
    p = A.pal(k)
    if fur:
        p['F'] = A.C(fur); p['D'] = A.mix(A.C(fur), 0.68); p['H'] = A.mix(A.C(fur), 0.3, True)
    if face:
        p['T'] = A.C(face)
    h, w = len(rows), len(rows[0])
    out = np.zeros((h * sc, w * sc, 4), np.float32)
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in p:
                out[y * sc:(y + 1) * sc, x * sc:(x + 1) * sc, :3] = p[ch]
                out[y * sc:(y + 1) * sc, x * sc:(x + 1) * sc, 3] = 1
    ys, xs = np.where(out[..., 3] > 0)
    y0 = ys.min()
    out = out[y0:ys.max() + 1]
    if flip:
        out = out[:, ::-1]
    return out, y0


def part_img(k, name, sc=2):
    rows = A.parts(k)[name] if name in A.parts(k) else A.FX[name]
    p = A.pal(k)
    im = _I.new('RGBA', (len(rows[0]), len(rows)), (0, 0, 0, 0))
    px_ = im.load()
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in p:
                px_[x, y] = p[ch] + (255,)
    return im.resize((im.size[0] * sc, im.size[1] * sc), _I.NEAREST)


layer = _I.new('RGBA', (W, H), (0, 0, 0, 0))


def arm(k, sx, sy, gx, gy, hand):
    seg = part_img(k, 'arm_segment')
    hd = part_img(k, hand)
    L = int(math.hypot(gx - sx, gy - sy))
    ang = math.degrees(math.atan2(gy - sy, gx - sx))
    full = _I.new('RGBA', (L + hd.size[0], max(seg.size[1], hd.size[1])), (0, 0, 0, 0))
    cy = full.size[1] // 2
    for x in range(0, L, seg.size[0]):
        full.paste(seg, (x, cy - seg.size[1] // 2))
    full.alpha_composite(hd, (L - 2, cy - hd.size[1] // 2))
    big = _I.new('RGBA', (full.size[0] * 2 + 4, full.size[0] * 2 + 4), (0, 0, 0, 0))
    ox, oy = big.size[0] // 2, big.size[1] // 2
    big.alpha_composite(full, (ox, oy - cy))
    rot = big.rotate(-ang, resample=_I.NEAREST, center=(ox, oy))
    layer.alpha_composite(rot, (int(sx - ox), int(sy - oy)))
    sh = part_img(k, 'shoulder')
    layer.alpha_composite(sh, (int(sx - sh.size[0] / 2), int(sy - sh.size[1] / 2)))


def put(k, fr, cx, bottom, hat='none', fur=None, face=None, flip=False):
    spr, y0 = chibi(k, fr, hat, fur, face, flip)
    return blit(spr, cx, bottom, flip=False), y0


placed['pip'], _ = put('capuchin', A.frame('capuchin', 'together', lift_l=2, lift_r=2), 44, 132, 'mushroom')
placed['tan'], _ = put('chimp', A.frame('chimp', 'stride', lift_l=1), 84, 186, 'tophat', '#a0693a', '#f0c89a')
placed['kong'], _ = put('gorilla', A.frame('gorilla', 'stride', lift_r=1), 414, 125, 'crown')
placed['green'], _ = put('chimp', A.frame('chimp', 'stride', lift_r=1), 266, 236, 'shades', '#5f9e4a', '#d9e6a8')
yf = A.frame('chimp', 'stride', noarm=True, dx_head=1, face='grit')
placed['you'], y0 = put('chimp', yf, 186, 150)
sx = placed['you'][0] + 11 * 2 + 1
sy = placed['you'][1] + (11 * 2 - y0) + 1
arm('chimp', sx, sy, sx + 30, sy, 'fist_big')
placed['mochi'], _ = put('chimp', A.frame('chimp', face='stun', squash=True), 274, 144, 'none', '#e07ab0', '#f6c7d9', flip=True)
lf = A.frame('spider', 'together', noarm=True, lift_l=1)
sp, sy0 = chibi('spider', lf)
bx, by = 312, 96
blit(sp, bx + sp.shape[1] / 2, None, top=by)
arm('spider', bx + 10 * 2 + 1, by + (10 * 2 - sy0) + 1, 300, 58, 'fist')
placed['lanky'] = (bx, by, sp.shape[1], sp.shape[0])
pw = part_img('chimp', 'fx_pow')
layer.alpha_composite(pw, (int(sx + 48), int(sy - 26)))
_la = np.array(layer).astype(np.float32)
_m = _la[..., 3] > 0
img[_m] = _la[..., :3][_m]

for (x, y) in [(266, 104), (276, 118), (258, 94)]:
    banana(x, y)
for i, (x, y) in enumerate([(262, 126), (266, 132), (268, 120)]):
    rect(x + 8, y, x + 14, y + 1, C('#f4e9cf'))
# stun stars over mochi
mx = placed['mochi']
for (dx, dy) in [(4, -4), (14, -6), (22, -3)]:
    x, y = mx[0] + dx, mx[1] + dy
    px(x, y, C('#ffd84a')); px(x - 1, y, C('#fff1a8')); px(x + 1, y, C('#fff1a8')); px(x, y - 1, C('#fff1a8')); px(x, y + 1, C('#fff1a8'))
# dust behind runner
for (x, y, r) in [(244, 232, 3), (236, 229, 2.5), (229, 233, 2)]:
    disc(x, y, r, C('#c9b89a'), dither=0.7)
# speed lines
for y in (218, 222, 226):
    rect(222, y, 236, y + 1, C('#f4e9cf') * 0.8)

# fireflies
for _ in range(26):
    x, y = random.randrange(40, 440), random.randrange(60, 230)
    px(x, y, C('#e8ff8a'))
    light(x, y, 7, (0.7, 0.9, 0.3), 0.8)
# falling leaves
for _ in range(8):
    x, y = random.randrange(W), random.randrange(40, 220)
    px(x, y, C('#7ec85a')); px(x + 1, y + 1, C('#4f9a3a'))

# foreground ferns
def fern(cx, by, h, flip=1):
    for i in range(h):
        x = cx + flip * (i * i) // (h * 2)
        y = by - i
        px(x, y, C('#07120c'))
        if i % 3 == 0:
            for k in range(1, 6 - i // (h // 5 + 1)):
                px(x - k, y + k // 2, C('#07120c'))
                px(x + k, y + k // 2, C('#07120c'))


for (cx, h, f) in [(-2, 34, 1), (8, 28, 1), (18, 22, -1), (474, 36, -1), (464, 28, -1), (454, 20, 1), (196, 14, 1), (330, 16, -1)]:
    fern(cx, H + 2, h, f)

# ---------- lighting ----------
Lq = np.floor(np.clip(L, 0, 1.4) * 7) / 7
out = img * (0.82 + Lq * 1.15) + Lq * 22
yy, xx = np.mgrid[0:H, 0:W]
vig = np.maximum(abs(xx - W / 2) / (W / 2), abs(yy - H / 2) / (H / 2))
vig = np.floor(np.clip((vig - 0.72) / 0.28, 0, 1) * 3) / 3
out = out * (1 - vig[..., None] * 0.35)
out = np.clip(out, 0, 255).astype(np.uint8)
im = Image.fromarray(out, 'RGB').resize((W * 2, H * 2), Image.NEAREST)
im.save('scene.png', optimize=True)
import json
json.dump({k: [int(v) for v in p] for k, p in placed.items()}, open('placed.json', 'w'))
print('ok', placed)
