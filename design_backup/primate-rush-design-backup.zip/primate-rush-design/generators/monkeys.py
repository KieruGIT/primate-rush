import numpy as np, math

OUT = np.array([20, 10, 6], np.float32)


def C(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], np.float32)


# ids: 1 fur, 7 dark fur, 8 far-side fur, 2 skin, 3 muzzle, 4 ink, 5 white,
#      6 hand/foot, 9 far hand, 16 silver, 10.. hat colours
def sprite_monkey(kind, pose, fur, face, hat='none', noarm=False, rot=0, want_anchor=False):
    S = 72
    ids = np.zeros((S, S), np.int8)
    k = {'chimp': 1.0, 'capuchin': 0.78, 'spider': 1.0, 'gorilla': 1.0}[kind]
    OX, OY = 8, 14

    def T(x, y):
        return OX + x * k, OY + y * k

    def e(cx, cy, rx, ry, m, only=None):
        cx, cy = T(cx, cy)
        rx, ry = rx * k, ry * k
        for y in range(max(0, int(cy - ry - 1)), min(S, int(cy + ry + 2))):
            for x in range(max(0, int(cx - rx - 1)), min(S, int(cx + rx + 2))):
                if ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2 <= 1:
                    if only is None or ids[y, x] in only:
                        ids[y, x] = m

    def pt(x, y, m):
        X, Y = T(x, y)
        X, Y = int(X), int(Y)
        if 0 <= X < S and 0 <= Y < S:
            ids[Y, X] = m

    def limb(pts, w, m, end=None, endm=6):
        for a, b in zip(pts, pts[1:]):
            n = int(math.hypot(b[0] - a[0], b[1] - a[1]) * 3) + 1
            for i in range(n + 1):
                t = i / n
                e(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, w / 2, w / 2, m)
        if end:
            e(pts[-1][0] + end[0], pts[-1][1], end[1], end[2], endm)

    lunge = pose == 'lunge'
    f = int(pose[-1]) if pose.startswith('walk') and pose[-1].isdigit() else 0

    def gait(ph):
        a = f * math.pi / 2 + ph
        return 4.2 * math.cos(a), max(0.0, 3.0 * math.sin(a))
    if pose == 'jump':
        gait = lambda ph: (1.5 if ph else -1.5, 2.5)
    g_nf, g_fr, g_ff, g_nr = gait(0), gait(0), gait(math.pi), gait(math.pi)
    anchor = None
    if kind == 'gorilla':
        dx, l = g_ff
        limb([(29, 28), (27 + dx / 2, 35 - l), (29 + dx, 42 - l)], 5, 8, (0, 3, 2), 9)
        dx, l = g_fr
        limb([(16, 32), (13 + dx / 2, 37 - l), (14 + dx, 42 - l)], 4.5, 8, (0, 2.6, 1.6), 9)
        e(17, 29, 6.5, 5.5, 1)
        e(28, 26, 9, 8, 1)
        e(26, 19.5, 7, 5, 1)
        e(19, 24.5, 5, 2.4, 16)
        e(32, 29, 3.6, 4.2, 2)
        dx, l = g_nr
        limb([(19, 32), (22 + dx / 2, 37 - l), (19 + dx, 42 - l)], 4.5, 1, (0.5, 2.6, 1.6))
        anchor = T(33, 27)
        dx, l = g_nf
        if not noarm:
            limb([(33, 27), (36 + dx / 2, 34 - l), (37 + dx, 42 - l)], 5.4, 1, (0.5, 3.2, 2))
        e(39, 22, 5.6, 5.4, 1)
        e(38, 17, 3, 2.3, 1)
        e(41.3, 23.5, 3.9, 3.8, 2)
        e(43.3, 25.5, 2.6, 2, 3)
        for x in range(38, 45):
            pt(x, 21, 7)
        pt(39.5, 22, 4); pt(42.5, 22, 4); pt(40, 22, 5)
        pt(43.5, 25, 4); pt(45, 25, 4)
        for x in range(42, 45):
            pt(x, 27, 4)
        e(34.5, 21, 1.6, 1.8, 1)
        head, eyes = (39, 16.5), (38, 45, 22)
    else:
        sp = kind == 'spider'
        lw, aw = (2.1, 2.0) if sp else (3.4, 3.0)
        drop = 3 if sp else 0
        if sp:
            limb([(14, 25), (8, 21), (5, 13), (7, 6), (12, 5), (13, 9), (10, 10)], 1.8, 1)
        else:
            limb([(13, 27), (8, 24), (6, 18), (8, 14), (11, 14)], 2.1, 1)
        # far limbs
        dx, l = g_ff
        limb([(28, 26 - drop), (25 + dx / 2, 33 - l), (27 + dx, 38 + drop - l)], aw, 8, (0, 2, 1.3), 9)
        dx, l = g_fr
        limb([(16, 29 - drop), (12 + dx / 2, 34 - l), (13 + dx, 38 + drop - l)], lw, 8, (0, 2, 1.3), 9)
        e(18, 28 - drop, 6 if not sp else 4.6, 5.3 if not sp else 4, 1)
        e(28, 26 - drop, 6.3 if not sp else 4.8, 5.8 if not sp else 4.3, 1)
        e(24, 31 - drop, 6.5 if not sp else 4.5, 2 if not sp else 1.4, 2 if kind != 'spider' else 2, only=[1])
        dx, l = g_nr
        limb([(18, 30 - drop), (22 + dx / 2, 34 - l), (18 + dx, 38 + drop - l)], lw, 1, (0.5, 2.1, 1.3))
        anchor = T(30, 25 - drop)
        dx, l = g_nf
        if noarm:
            pass
        elif lunge:
            limb([(30, 25), (36, 22), (43, 17)], aw, 1, (0.6, 2.2, 2.2))
        else:
            limb([(30, 26 - drop), (33 + dx / 2, 32 - l), (34 + dx, 38 + drop - l)], aw, 1, (0.5, 2.1, 1.3))
        hy = 19 - drop
        e(35, hy, 7.2 if not sp else 5.8, 7 if not sp else 5.6, 1)
        e(29.4, hy, 2.4, 2.5, 1)
        e(29.4, hy, 1.2, 1.3, 2)
        e(40, hy - 4, 1.6, 1.8, 1)
        if kind == 'capuchin':
            e(37, hy + 1, 5, 4.8, 2, only=[1])
            e(35, hy - 3.3, 5.6, 3.2, 7, only=[1, 2])
        else:
            e(37.6, hy + 1.2, 4.1, 4.2, 2)
            e(35.8, hy - 0.6, 2.3, 2.1, 2)
            e(39.4, hy - 0.6, 2.1, 2.1, 2)
        e(40.6, hy + 3.4, 3 if not sp else 2.4, 2.2 if not sp else 1.8, 3)
        if pose == 'stun':
            for (x, y) in [(35, hy), (37, hy), (36, hy + 1), (35, hy + 2), (37, hy + 2)]:
                pt(x, y - 1, 4)
            pt(39.5, hy - 1, 4); pt(40.5, hy, 4); pt(39.5, hy + 1, 4)
            e(41, hy + 5, 1.2, 1, 4)
        else:
            pt(35, hy, 4); pt(36, hy, 4); pt(35, hy + 1, 4); pt(36, hy + 1, 4); pt(36, hy, 5)
            pt(39.5, hy, 4); pt(39.5, hy + 1, 4)
            pt(42, hy + 3, 4); pt(43.2, hy + 3, 4)
            for x in (39.5, 40.5, 41.5):
                pt(x, hy + 5, 4)
            if lunge:
                e(41, hy + 5.5, 1.3, 0.9, 4)
        head, eyes = (35, hy - 7.2), (34, 41, hy)

    hats = {
        'crown': ['A.A.A.A', 'AARAARA', 'AAAAAAA', 'BBBBBBB'],
        'mushroom': ['...RRRRR...', '.RRWRRRWRR.', 'RRRRRWWRRRR', 'RWRRRRRRRWR', '..SSSSSSS..'],
        'tophat': ['..KKKKK..', '..KKKKK..', '..KKKKK..', '..KRRRK..', 'KKKKKKKKK'],
    }
    hid = {'A': 10, 'B': 14, 'R': 11, 'W': 12, 'S': 15, 'K': 13}
    if hat in hats:
        rows = hats[hat]
        hx, hy0 = T(*head)
        for j, row in enumerate(rows):
            y = int(hy0) - len(rows) + 2 + j
            for i, ch in enumerate(row):
                if ch != '.':
                    ids[y, int(hx) - len(row) // 2 + i] = hid[ch]
    if hat == 'shades':
        x0, y0 = T(eyes[0], eyes[2])
        x1, _ = T(eyes[1], eyes[2])
        for x in range(int(x0), int(x1) + 1):
            ids[int(y0), x] = 13
            ids[int(y0) + 1, x] = 13 if x not in (int(x0) + 3,) else ids[int(y0) + 1, x]
        ids[int(y0), int(x0) + 1] = 12

    if pose == 'stun':
        rot = 24
    if rot:
        ids = rotate(ids, rot)
        if anchor is not None:
            a = math.radians(rot); c = S / 2
            x, y = anchor[0] - c, anchor[1] - c
            anchor = (math.cos(a) * x - math.sin(a) * y + c, math.sin(a) * x + math.cos(a) * y + c)
    if pose == 'climb':
        ids = np.rot90(ids, 1)[:, ::-1].copy()

    fur_c, face_c = C(fur), C(face)
    pal = {1: fur_c, 7: fur_c * 0.6, 8: fur_c * 0.58, 2: face_c, 3: np.minimum(255, face_c + (255 - face_c) * 0.32),
           4: OUT, 5: C('#ffffff'), 6: face_c * 0.68, 9: face_c * 0.45, 16: C('#9ea0b0'),
           10: C('#f7c948'), 14: C('#c8901e'), 11: C('#d93b3b'), 12: C('#fff4e0'), 13: C('#1b1b1f'), 15: C('#e8d8b0')}
    out = np.zeros((S, S, 4), np.float32)
    ys, xs = np.where(ids > 0)
    cy = ys.mean() if len(ys) else S / 2
    for y, x in zip(ys, xs):
        m = ids[y, x]
        c = pal[m].copy()
        if m in (1, 2, 3, 6, 7, 8, 16, 10, 11):
            up = ids[y - 1, x] == 0
            lf = ids[y, x - 1] == 0
            dn = ids[y + 1, x] == 0
            rt = ids[y, x + 1] == 0
            if up:
                c = np.minimum(255, c * 1.28 + 12)
            elif lf:
                c = np.minimum(255, c * 1.12 + 6)
            elif dn:
                c = c * 0.66
            elif rt:
                c = c * 0.8
            elif y > cy + 3 and m in (1, 2):
                c = c * 0.86
        out[y, x, :3] = c
        out[y, x, 3] = 1
    filled = out[..., 3] > 0
    o2 = out.copy()
    for y in range(1, S - 1):
        for x in range(1, S - 1):
            if not filled[y, x] and (filled[y - 1, x] or filled[y + 1, x] or filled[y, x - 1] or filled[y, x + 1]):
                o2[y, x, :3] = OUT
                o2[y, x, 3] = 1
    ys, xs = np.where(o2[..., 3] > 0)
    spr = o2[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    if want_anchor:
        return spr, (anchor[0] - xs.min(), anchor[1] - ys.min())
    return spr


def rotate(ids, deg):
    S = ids.shape[0]
    a = math.radians(deg)
    out = np.zeros_like(ids)
    c = S / 2
    for y in range(S):
        for x in range(S):
            sx = math.cos(a) * (x - c) + math.sin(a) * (y - c) + c
            sy = -math.sin(a) * (x - c) + math.cos(a) * (y - c) + c
            ix, iy = int(round(sx)), int(round(sy))
            if 0 <= ix < S and 0 <= iy < S:
                out[y, x] = ids[iy, ix]
    return out


if __name__ == '__main__':
    from PIL import Image
    roster = [('chimp', 'walk', '#8b5a2b', '#e8b98a', 'none'), ('gorilla', 'walk', '#3a3440', '#9a8a8a', 'none'),
              ('chimp', 'walk', '#a0693a', '#f0c89a', 'mushroom'), ('chimp', 'walk', '#e07ab0', '#f6c7d9', 'crown'),
              ('spider', 'walk', '#5f4a3a', '#e0c0a0', 'none'), ('capuchin', 'walk', '#c98a4a', '#f6e3c0', 'shades'),
              ('chimp', 'walk', '#5f9e4a', '#d9e6a8', 'tophat'), ('gorilla', 'walk', '#3a3440', '#9a8a8a', 'crown')]
    sprs = [sprite_monkey(*r) for r in roster]
    Wd = sum(s.shape[1] for s in sprs) + 12 * (len(sprs) + 1)
    Hd = max(s.shape[0] for s in sprs) + 24
    bg = np.zeros((Hd, Wd, 3), np.float32) + C('#0e1530')
    bg[Hd - 8:, :] = C('#4f9a3a'); bg[Hd - 8, :] = C('#8fd14f'); bg[Hd - 5:, :] = C('#3a2616')
    x = 12
    for s in sprs:
        h, w = s.shape[:2]
        y = Hd - 8 - h
        m = s[..., 3] > 0
        bg[y:y + h, x:x + w][m] = s[..., :3][m]
        x += w + 12
    Image.fromarray(np.clip(bg, 0, 255).astype(np.uint8)).resize((Wd * 4, Hd * 4), Image.NEAREST).save('lineup.png')
    print(Wd, Hd)
