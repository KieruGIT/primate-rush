import numpy as np, math, json
from PIL import Image
from monkeys import sprite_monkey, C, OUT

KINDS = {
    'chimp': ('#8b5a2b', '#e8b98a', 4),
    'gorilla': ('#3a3440', '#9a8a8a', 6),
    'spider': ('#5f4a3a', '#e0c0a0', 3),
    'capuchin': ('#c98a4a', '#f6e3c0', 3),
}


def rgba(a):
    return Image.fromarray(np.clip(a * np.array([1, 1, 1, 255.0]) if a.max() <= 1.001 and False else a, 0, 255).astype(np.uint8), 'RGBA')


def to_img(spr):
    out = np.zeros(spr.shape, np.uint8)
    out[..., :3] = np.clip(spr[..., :3], 0, 255)
    out[..., 3] = (spr[..., 3] > 0) * 255
    return Image.fromarray(out, 'RGBA')


def shade_render(ids, fur, face):
    pal = {1: C(fur), 6: C(face) * 0.68, 7: C(face) * 0.5}
    H, W = ids.shape
    out = np.zeros((H + 2, W + 2, 4), np.float32)
    g = np.zeros((H + 2, W + 2), np.int8)
    g[1:-1, 1:-1] = ids
    for y in range(1, H + 1):
        for x in range(1, W + 1):
            m = g[y, x]
            if not m:
                if g[y - 1, x] or g[y + 1, x] or g[y, x - 1] or g[y, x + 1]:
                    out[y, x, :3] = OUT; out[y, x, 3] = 1
                continue
            c = pal[m].copy()
            if g[y - 1, x] == 0:
                c = np.minimum(255, c * 1.28 + 12)
            elif g[y + 1, x] == 0:
                c = c * 0.66
            out[y, x, :3] = c; out[y, x, 3] = 1
    for x in range(W + 2):  # outline at canvas edge rows if touching
        pass
    return out


def hand(kind, closed, fur, face):
    s = {'gorilla': 1.5, 'spider': 0.95, 'capuchin': 0.95}.get(kind, 1.15)
    N = int(12 * s) + 2
    ids = np.zeros((N, N), np.int8)

    def e(cx, cy, rx, ry, m):
        cx, cy, rx, ry = cx * s, cy * s, rx * s, ry * s
        for y in range(N):
            for x in range(N):
                if ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2 <= 1:
                    ids[y, x] = m

    def ln(a, b, w, m):
        n = 20
        for i in range(n + 1):
            t = i / n
            e(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, w / 2, w / 2, m)
    e(1.6, 6, 1.8, 2.3, 1)
    if closed:
        e(5.6, 6, 3.4, 3.1, 6)
        for y in (4, 5, 6, 7):
            ids[int(y * s), int(7.2 * s)] = 7
        ln((4.2, 3.6), (5.4, 2.4), 1.4, 6)
    else:
        e(4.8, 6, 2.8, 2.6, 6)
        for tip in [(10.5, 2.6), (11.2, 5), (11, 7.4), (9.4, 9.6)]:
            ln((6, 6), tip, 1.4, 6)
        ln((4.6, 4.4), (5.6, 1.2), 1.4, 6)
    ys, xs = np.where(ids > 0)
    ids = ids[:, :xs.max() + 1]
    out = shade_render(ids, fur, face)
    return out, (1, out.shape[0] / 2)


def segment(kind, fur, t):
    L = 12
    core = C(fur)
    rows = [OUT, np.minimum(255, core * 1.28 + 12)] + [core] * max(1, t - 2) + [core * 0.66, OUT]
    out = np.zeros((len(rows), L, 4), np.float32)
    for j, c in enumerate(rows):
        out[j, :, :3] = c
        out[j, :, 3] = 1
    mid = len(rows) // 2
    for x in (3, 9):
        out[mid, x, :3] = core * 0.82
    out[mid - 1, 6, :3] = core * 1.1
    return out


def shoulder(fur, t):
    r = t / 2 + 1
    N = int(2 * r) + 3
    ids = np.zeros((N, N), np.int8)
    for y in range(N):
        for x in range(N):
            if (x + .5 - N / 2) ** 2 + (y + .5 - N / 2) ** 2 <= r * r:
                ids[y, x] = 1
    out = np.zeros((N, N, 4), np.float32)
    ys, xs = np.where(ids > 0)
    for y, x in zip(ys, xs):
        c = C(fur) * (1.2 if y < N / 2 - 1 else 1.0 if y < N / 2 + 1 else 0.8)
        out[y, x, :3] = np.minimum(255, c); out[y, x, 3] = 1
    return out


parts = {}
anchors = {}
for kind, (fur, face, t) in KINDS.items():
    for i in range(4):
        parts[f'{kind}/walk{i}'] = sprite_monkey(kind, f'walk{i}', fur, face)
    parts[f'{kind}/jump'] = sprite_monkey(kind, 'jump', fur, face)
    spr, a = sprite_monkey(kind, 'walk0', fur, face, noarm=True, rot=-20, want_anchor=True)
    parts[f'{kind}/reach_body'] = spr; anchors[f'{kind}/reach_body'] = {'shoulder': [round(a[0], 1), round(a[1], 1)]}
    spr, a = sprite_monkey(kind, 'jump', fur, face, noarm=True, rot=-68, want_anchor=True)
    parts[f'{kind}/swing_body'] = spr; anchors[f'{kind}/swing_body'] = {'shoulder': [round(a[0], 1), round(a[1], 1)]}
    parts[f'{kind}/shoulder'] = shoulder(fur, t)
    parts[f'{kind}/arm_segment'] = segment(kind, fur, t)
    anchors[f'{kind}/arm_segment'] = {'pivot': [0, parts[f'{kind}/arm_segment'].shape[0] / 2], 'tile': 'x'}
    h, a = hand(kind, False, fur, face); parts[f'{kind}/hand_open'] = h; anchors[f'{kind}/hand_open'] = {'wrist': list(a)}
    h, a = hand(kind, True, fur, face); parts[f'{kind}/hand_grip'] = h; anchors[f'{kind}/hand_grip'] = {'wrist': list(a)}

# pack: one row per kind
order = ['walk0', 'walk1', 'walk2', 'walk3', 'jump', 'reach_body', 'swing_body', 'shoulder', 'arm_segment', 'hand_open', 'hand_grip']
PAD = 4
rowh = {k: max(parts[f'{k}/{o}'].shape[0] for o in order) for k in KINDS}
Wt = max(sum(parts[f'{k}/{o}'].shape[1] + PAD for o in order) + PAD for k in KINDS)
Ht = sum(rowh.values()) + PAD * (len(KINDS) + 1)
sheet = Image.new('RGBA', (Wt, Ht), (0, 0, 0, 0))
frames = {}
y = PAD
for k in KINDS:
    x = PAD
    for o in order:
        p = parts[f'{k}/{o}']
        h, w = p.shape[:2]
        yy = y + rowh[k] - h
        sheet.paste(to_img(p), (x, yy))
        frames[f'{k}/{o}'] = {'x': x, 'y': yy, 'w': w, 'h': h, **anchors.get(f'{k}/{o}', {})}
        x += w + PAD
    y += rowh[k] + PAD
sheet.save('monkey_sheet.png')
json.dump({'image': 'monkey_sheet.png', 'pixel_scale_hint': 2, 'frames': frames,
           'notes': 'Anchors are in pixels relative to each frame top-left. Arm = shoulder at body.shoulder, '
                    'arm_segment tiled along x from shoulder to hand, hand wrist placed at arm end, rotated to arm angle.'},
          open('monkey_sheet.json', 'w'), indent=1)

# preview of sheet on dark bg with labels-free grid
bg = Image.new('RGBA', (Wt, Ht), (14, 21, 48, 255))
bg.alpha_composite(sheet)
bg.convert('RGB').resize((Wt * 4, Ht * 4), Image.NEAREST).save('sheet_preview.png')


# ---- swing composite preview ----
def compose_arm(canvas, kind, body_key, body_pos, grip, open_hand=False, flip=False):
    fur, face, t = KINDS[kind]
    body = to_img(parts[f'{kind}/{body_key}'])
    sh = anchors[f'{kind}/{body_key}']['shoulder']
    bx, by = body_pos
    sx, sy = bx + sh[0], by + sh[1]
    gx, gy = grip
    L = int(math.hypot(gx - sx, gy - sy))
    ang = math.degrees(math.atan2(gy - sy, gx - sx))
    seg = to_img(parts[f'{kind}/arm_segment'])
    sw, shh = seg.size
    strip = Image.new('RGBA', (L, shh), (0, 0, 0, 0))
    for x in range(0, L, sw):
        strip.paste(seg, (x, 0))
    hnd = to_img(parts[f'{kind}/hand_open' if open_hand else f'{kind}/hand_grip'])
    full = Image.new('RGBA', (L + hnd.size[0], max(shh, hnd.size[1])), (0, 0, 0, 0))
    cy = full.size[1] // 2
    full.paste(strip, (0, cy - shh // 2), strip)
    full.alpha_composite(hnd, (L - 1, cy - hnd.size[1] // 2))
    big = Image.new('RGBA', (full.size[0] * 2 + 4, full.size[0] * 2 + 4), (0, 0, 0, 0))
    ox, oy = big.size[0] // 2, big.size[1] // 2
    big.alpha_composite(full, (ox, oy - cy))
    rot = big.rotate(-ang, resample=Image.NEAREST, center=(ox, oy))
    canvas.alpha_composite(body, (int(bx), int(by)))
    canvas.alpha_composite(rot, (int(sx - ox), int(sy - oy)))
    shd = to_img(parts[f'{kind}/shoulder'])
    canvas.alpha_composite(shd, (int(sx - shd.size[0] / 2), int(sy - shd.size[1] / 2)))


if __name__ == '__main__':
    PW, PH = 320, 150
    pv = Image.new('RGBA', (PW, PH), (0, 0, 0, 255))
    arr = np.zeros((PH, PW, 4), np.uint8)
    for yy in range(PH):
        c = C('#0e1634') * (1 - yy / PH) + C('#223463') * (yy / PH)
        arr[yy, :, :3] = c; arr[yy, :, 3] = 255
    arr[PH - 10:, :, :3] = C('#3a2616'); arr[PH - 10:PH - 7, :, :3] = C('#4f9a3a'); arr[PH - 10, :, :3] = C('#8fd14f')
    for (x0, x1, yb) in [(60, 140, 22), (190, 300, 16)]:
        arr[yb:yb + 5, x0:x1, :3] = C('#5a3920'); arr[yb, x0:x1, :3] = C('#7a5230'); arr[yb + 5, x0:x1, :3] = OUT
        arr[yb - 1, x0:x1, :3] = OUT
    pv = Image.fromarray(arr, 'RGBA')
    # 1: reaching up, open hand shooting out
    b = parts['chimp/reach_body']
    compose_arm(pv, 'chimp', 'reach_body', (20, 70), (86, 30), open_hand=True)
    # 2: gripping, long stretch swing
    compose_arm(pv, 'chimp', 'swing_body', (140, 72), (100, 24))
    # 3: gorilla grip
    compose_arm(pv, 'gorilla', 'swing_body', (238, 60), (262, 18))
    pv.convert('RGB').resize((PW * 4, PH * 4), Image.NEAREST).save('swing_preview.png')
    print(Wt, Ht, json.dumps({k: v for k, v in frames.items() if 'chimp' in k}, indent=0)[:600])
