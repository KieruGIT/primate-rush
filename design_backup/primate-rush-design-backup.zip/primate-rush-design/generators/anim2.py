import json
from PIL import Image


def C(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(c, f, white=False):
    return tuple(int(round(v + (255 - v) * f)) if white else int(round(v * f)) for v in c)


B16 = '................'
KINDS = {
    'chimp': dict(fur='#8b5a2b', face='#e8b98a', skin='#d9a878', arm_t=5,
        rows=[B16, B16, B16, '.....OOOOOO.....', '....OFHHFFDO....', '.OOOFHFFFFFDOOO.', 'OTTOFTTFFTTDOTTO',
              'OTTOTEPTTEPTOTTO', '.OOOTTTTTTTTOOO.', '....OTTMMTTO....', '....ODTTTTDO....',
              '...OFFOOOOFDO.OO', '..OFFOTTTTODDOFO', '..OOFOTTTTODOODO', '...OFFOOOOFDOO..', '...OOO....OOO...'],
        head=(3, 10), arm_rows=(11, 13), L=(2, 4, 5), R=(11, 12, 10), legs_rows=(14, 15), legs_cols=(2, 13),
        waist=13, shoulder=(11, 11)),
    'gorilla': dict(fur='#3a3440', face='#b89a8a', skin='#8a7a7a', arm_t=7,
        rows=['....................'] * 3 + ['........OOOO........', '.......ODDDDO.......', '......ODDDDDDO......',
              '......OTPTTPTO......', '......OTTMMTTO......', '....OOODTTTTDOOO....', '...OFHHFDDDDFHHFO...',
              '..OFFFSSSSSSSSFFDO..', '.OFFFOSSSSSSSSOFFDO.', '.OFFFOSSSSSSSSOFFDO.', '.OFFFOOSSSSSSOOFFDO.',
              '.OFFFO.ODDDDO.OFFDO.', 'OFFFFO.ODDDDO.OFFDDO', 'ODDDDO.ODOODO.ODDDDO', 'OOOOO.ODDOODDO.OOOOO',
              '......OOO..OOO......'],
        head=(3, 8), arm_rows=(10, 17), L=(0, 4, 5), R=(15, 19, 14), legs_rows=(17, 18), legs_cols=(6, 13),
        waist=13, shoulder=(15, 10)),
    'spider': dict(fur='#5f4a3a', face='#e0c0a0', skin='#c9a584', arm_t=4,
        rows=['..............'] * 3 + ['.....OOOO.....', '....OHFFDO....', '...OFTTTTDO...', '...OTPTTPTO...',
              '...OFTMMTDO.D.', '....OFFFDO..DD', '...OOFFFFOO..D', '..OFOFTTFOFO.D', '..OFOFTTFODO.D',
              '..OFOFTTFODO.D', '..OFOFFFDODO.D', '..OFOOFFOODODD', '..OFOD..DODO..', '..ODOD..DODO..',
              '..OOOD..DOOO..', '.....D..D.....', '....OD..DO....', '....OO..OO....'],
        head=(3, 8), arm_rows=(10, 17), L=(2, 3, 4), R=(10, 11, 9), legs_rows=(18, 20), legs_cols=(4, 9),
        waist=14, shoulder=(10, 10)),
    'capuchin': dict(fur='#c98a4a', face='#f6e3c0', skin='#e6c9a0', arm_t=4,
        rows=['............'] * 3 + ['....OOOO....', '...OHFFDO...', '..OFTTTTDO..', '..OTPTTPTO..', '..OFTMMTDO..',
              '...OFFFDO.OD', '..OFOTTODOD.', '..OFOTTODO.D', '...OFOODO.D.', '...OO..OO...'],
        head=(3, 7), arm_rows=(9, 11), L=(2, 3, 4), R=(8, 9, 7), legs_rows=(12, 12), legs_cols=(2, 9),
        waist=10, shoulder=(8, 9)),
}


HATS = {'crown': ['Y.YY.Y', 'YYYYYY', 'YRYYRY'], 'mushroom': ['..RRRRRR..', '.RWRRRRWR.', 'RRRRWWRRRR'],
        'tophat': ['..KKKK..', '..KRRK..', 'KKKKKKKK']}
CX = {'chimp': 8, 'gorilla': 10, 'spider': 7, 'capuchin': 6}
EYE = {'chimp': (7, 4, 11), 'gorilla': (6, 7, 12), 'spider': (6, 4, 9), 'capuchin': (6, 3, 8)}


def dress(k, rows, hat):
    g = [list(r) for r in rows]
    top = next(i for i, r in enumerate(g) if any(c != '.' for c in r))
    if hat in HATS:
        h = HATS[hat]
        for j, row in enumerate(h):
            y = top - len(h) + j
            x0 = CX[k] - len(row) // 2
            for i, ch in enumerate(row):
                if ch != '.' and 0 <= y:
                    g[y][x0 + i] = ch
    if hat == 'shades':
        r, a, b = EYE[k]
        r = r - 3 + top
        for x in range(a, b + 1):
            g[r][x] = 'K'
    return [''.join(r) for r in g]


def frame(k, legs='stand', lift_l=0, lift_r=0, noarm=False, dy=0, dx_head=0, face=None, squash=False):
    s = KINDS[k]
    g = [list(r) for r in s['rows']]
    W, H = len(g[0]), len(g)
    a0, a1 = s['arm_rows']

    def arm_cells(side):
        c0, c1, _ = s[side]
        return [(r, c) for r in range(a0, a1 + 1) for c in range(c0, c1 + 1)]
    if noarm:
        for (r, c) in arm_cells('R'):
            g[r][c] = '.'
        e = s['R'][2]
        for r in range(a0, a1 + 1):
            if g[r][e] != '.':
                g[r][e] = 'O'
    for side, lift in (('L', lift_l), ('R', 0 if noarm else lift_r)):
        if not lift:
            continue
        cells = {(r, c): g[r][c] for r, c in arm_cells(side)}
        for rc in cells:
            g[rc[0]][rc[1]] = '.'
        for (r, c), v in cells.items():
            if v != '.' and r - lift >= 0:
                g[r - lift][c] = v
        e = s[side][2]
        for r in range(a0, a1 + 1):
            if g[r][e] != '.':
                g[r][e] = 'O'
    l0, l1 = s['legs_rows']
    c0, c1 = s['legs_cols']
    mid = (c0 + c1) / 2
    if legs in ('stride', 'together'):
        out = 1 if legs == 'stride' else -1
        for r in range(l0, l1 + 1):
            old = g[r][:]
            for c in range(c0, c1 + 1):
                g[r][c] = '.'
            for c in range(c0, c1 + 1):
                if old[c] != '.':
                    nc = c - out if c < mid else c + out
                    if c0 - 1 <= nc <= c1 + 1:
                        g[r][nc] = old[c]
    if legs == 'tuck':
        for c in range(c0, c1 + 1):
            g[l1][c] = '.'
    if face in ('stun', 'grit'):
        for r in range(*s['head']):
            for c in range(W):
                if face == 'stun' and g[r][c] == 'E':
                    g[r][c] = 'T'
                if face == 'stun' and g[r][c] == 'M':
                    g[r][c] = 'P'
                if face == 'grit' and g[r][c] == 'M':
                    g[r][c] = 'W'
    if dx_head:
        h0, h1 = s['head']
        for r in range(h0, h1 + 1):
            row = g[r]
            g[r] = (['.'] * dx_head + row[:-dx_head]) if dx_head > 0 else (row[-dx_head:] + ['.'] * -dx_head)
    if squash:
        w = s['waist']
        top = [g[r][:] for r in range(0, w)]
        for r in range(1, w + 1):
            g[r] = top[r - 1]
        g[0] = ['.'] * W
    if dy < 0:
        g = g[-dy:] + [['.'] * W for _ in range(-dy)]
    return [''.join(r) for r in g]


def pal(k):
    s = KINDS[k]
    fur, face, skin = C(s['fur']), C(s['face']), C(s['skin'])
    return {'O': C('#1a0f0a'), 'F': fur, 'D': mix(fur, 0.68), 'H': mix(fur, 0.3, True), 'T': face,
            'S': mix(face, 0.78), 'E': (255, 255, 255), 'P': (17, 17, 17), 'M': C('#5a2a1a'),
            'K': C('#1b1b1f'), 'Y': C('#ffd84a'), 'W': C('#fff4e0'), 'R': C('#d93b3b'),
            'h': skin, 'l': mix(skin, 0.35, True), 'k': mix(skin, 0.72), 'G': C('#c9b89a')}


def parts(k):
    t = KINDS[k]['arm_t']
    seg = ['OOOOOOOO', 'HHHHHHHH'] + ['FFFDFFFF' if i == (t - 4) // 2 else 'FFFFFFFF' for i in range(t - 4)] + ['DDDDDDDD', 'OOOOOOOO']
    return {
        'arm_segment': seg,
        'shoulder': ['.OOO.', 'OHHFO', 'OFFFO', 'ODDDO', '.OOO.'],
        'hand_open': ['...OO......', '..OhhO.OOOO', 'OOOhhOOhhhO', 'OFFhhhhOOOO', 'OFFhhhhhhhO', 'OFFhhhhOOOO',
                      'OOOhhhhhhhO', '..OhhhOOOOO', '...OOO.....'],
        'fist': ['...OOOOO.', '..OllllhO', 'OOOhlhlhO', 'OFFhhhhhO', 'OFFOhhhkO', 'OOOhhhhkO', '..OhhhkkO', '...OOOOO.'],
        'fist_big': ['....OOOOOOOO..', '...OllllllhhO.', 'OOOOhhhhhhhhkO', 'OFFOhhhhhkkkkO', 'OFFOhhhhhhhhkO',
                     'OFFOhhhhhkkkkO', 'OFFOhhhhhhhhkO', 'OFFOllllOkkkkO', 'OOOOhhhhhOhhkO', '...OkhhhhhhkO.',
                     '....OkkkkkkO..', '.....OOOOOO...'],
    }


FX = {
    'fx_pow': ['.....OO.....', '..O..OYO..O.', '..OOOYYOOYO.', '...OYWWYYO..', '.OOYWWWWYOO.', 'OYYWWWWWWYYO',
               '.OOYWWWWYOO.', '..OYYWWYYO..', '.OYOOYYOOYO.', '.O...OYO..O.', '.....OO.....'],
    'fx_star': ['..Y..', '.YWY.', 'YWWWY', '.YWY.', '..Y..'],
    'fx_dust': ['..GG..', '.GGGG.', 'GGGGGG', '.GG.GG'],
}


def anims(k):
    return [
        ('idle', 3, True, [frame(k), frame(k, squash=True)]),
        ('walk', 8, True, [frame(k, 'stride', lift_l=1), frame(k, 'together', dy=-1), frame(k, 'stride', lift_r=1), frame(k, 'together', dy=-1)]),
        ('jump', 1, False, [frame(k, 'tuck', lift_l=2, lift_r=2, dy=-1)]),
        ('fall', 1, False, [frame(k, 'stride', lift_l=3, lift_r=3)]),
        ('hit', 1, False, [frame(k, face='stun', squash=True)]),
        ('swing_hold', 1, False, [frame(k, 'together', noarm=True, lift_l=1)]),
        ('punch_windup', 1, False, [frame(k, noarm=True, squash=True, dx_head=-1, face='grit')]),
        ('punch', 1, False, [frame(k, 'stride', noarm=True, dx_head=1, face='grit')]),
    ]


CELL = 24
ORDER = ['chimp', 'gorilla', 'spider', 'capuchin']


def blit(im, rows, ox, oy, p):
    px = im.load()
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in p:
                px[ox + x, oy + y] = p[ch] + (255,)


def build():
    n = sum(len(f) for _, _, _, f in anims('chimp'))
    PART_H = 14
    Wd = CELL * n
    Hd = (CELL + PART_H) * len(ORDER) + 12
    sheet = Image.new('RGBA', (Wd, Hd), (0, 0, 0, 0))
    meta = {'image': 'monkey_anim.png', 'cell': [CELL, CELL], 'origin': 'bottom-center of each cell',
            'punch': {'direction': 'horizontal only, toward facing side', 'reach_px': 20, 'fist': 'fist_big'},
            'swing': {'hand_flying': 'hand_open', 'hand_holding': 'fist', 'max_reach_px': 96},
            'kinds': {}}
    y = 0
    for k in ORDER:
        p = pal(k)
        km = {'animations': {}, 'parts': {}}
        i = 0
        for name, fps, loop, frames in anims(k):
            cells = []
            for f in frames:
                w, h = len(f[0]), len(f)
                ox = i * CELL + (CELL - w) // 2
                oy = y + CELL - h
                blit(sheet, f, ox, oy, p)
                cells.append([i * CELL, y, CELL, CELL])
                i += 1
            km['animations'][name] = {'fps': fps, 'loop': loop, 'frames': cells}
        w0, h0 = len(KINDS[k]['rows'][0]), len(KINDS[k]['rows'])
        sx, sy = KINDS[k]['shoulder']
        km['shoulder_in_cell'] = [(CELL - w0) // 2 + sx, CELL - h0 + sy]
        x = 0
        py = y + CELL + 1
        for name, rows in list(parts(k).items()):
            blit(sheet, rows, x, py, p)
            km['parts'][name] = {'x': x, 'y': py, 'w': len(rows[0]), 'h': len(rows)}
            x += len(rows[0]) + 2
        meta['kinds'][k] = km
        y += CELL + PART_H
    x = 0
    for name, rows in FX.items():
        blit(sheet, rows, x, y, pal('chimp'))
        meta.setdefault('fx', {})[name] = {'x': x, 'y': y, 'w': len(rows[0]), 'h': len(rows)}
        x += len(rows[0]) + 2
    sheet.save('monkey_anim.png')
    json.dump(meta, open('monkey_anim.json', 'w'), indent=1)
    # preview: per-kind animation strip (4x) and parts strip (4x) on transparent bg
    for idx, k in enumerate(ORDER):
        yy = idx * (CELL + PART_H)
        sheet.crop((0, yy, Wd, yy + CELL)).resize((Wd * 4, CELL * 4), Image.NEAREST).save(f'strip_{k}.png')
    sheet.crop((0, 0, Wd, Hd)).resize((Wd * 4, Hd * 4), Image.NEAREST).save('monkey_anim_4x.png')
    return sheet, meta


if __name__ == '__main__':
    s, m = build()
    print(s.size)
